# Android_Calculator

<img src="https://user-images.githubusercontent.com/38129975/59274577-400bf380-8c78-11e9-8f6f-96990fb0bd32.jpeg" width="280px" height="500px"><img src="https://user-images.githubusercontent.com/38129975/59274604-4d28e280-8c78-11e9-809b-42c1eb705c0e.jpeg" width="280px" height="500px" align="right">

<img src="https://user-images.githubusercontent.com/38129975/59274628-5a45d180-8c78-11e9-8426-e7735193c285.jpeg" width="280px" height="500px"><img src="https://user-images.githubusercontent.com/38129975/59274825-c1638600-8c78-11e9-8463-f086d522ddcd.jpeg" width="280px" height="500px" align="right">
